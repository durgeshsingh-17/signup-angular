import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comps',
  templateUrl: './comps.component.html',
  styleUrls: ['./comps.component.scss']
})
export class CompsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
