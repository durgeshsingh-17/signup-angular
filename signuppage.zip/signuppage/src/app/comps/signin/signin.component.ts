import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss']
})
export class SigninComponent implements OnInit {

  login = new FormGroup({
    email: new FormControl('', [
      Validators.required,
      Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')
    ]),

    password: new FormControl('',
      Validators.compose([
      Validators.required,
      Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}$'),

    ])),
  });

  get email() {
    return this.login.get('email')!;
  }

  get password() {
    return this.login.get('password')!;
  }

  constructor() { }

  ngOnInit(): void {
  }

  onSubmit() {
    console.log(this.login)
    localStorage.setItem("data", JSON.stringify(this.login.value))
  }
}
