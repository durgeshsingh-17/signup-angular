import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CompsRoutingModule } from './comps-routing.module';
import { CompsComponent } from './comps.component';


@NgModule({
  declarations: [
    CompsComponent
  ],
  imports: [
    CommonModule,
    CompsRoutingModule
  ]
})
export class CompsModule { }
