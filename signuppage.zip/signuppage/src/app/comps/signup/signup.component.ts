import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {

  signUpForm = new FormGroup({
    name: new FormControl('', [
      Validators.required,
      Validators.minLength(3),
    ]),

    email: new FormControl('', [
      Validators.required,
      Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')
    ]),

    password: new FormControl('',
      Validators.compose([
      Validators.required,
      Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}$'),

    ])),
    conPassword: new FormControl('',
      Validators.compose([
      Validators.required,
      Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}$'),
    ])),
  });

  get name() {
    return this.signUpForm.get('name')!;
  }

  get email() {
    return this.signUpForm.get('email')!;
  }

  get password() {
    return this.signUpForm.get('password')!;
  }

  get conPassword() {
    return this.signUpForm.get('conPassword')!;
  }

  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    console.log(this.signUpForm)
    
  }

  onSubmit() {
    console.log(this.signUpForm)
    // console.log(this.signUpForm.controls.password.value)
    // console.log(this.signUpForm.controls.conPassword.value)
    if(this.signUpForm.controls.password.value==this.signUpForm.controls.conPassword.value)
    {
      localStorage.setItem("data", JSON.stringify(this.signUpForm.value))
      // console.log("if")
    }
    
  }
}
