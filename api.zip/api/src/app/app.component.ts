import { Component } from '@angular/core';
import { freeApiService } from './services/freeapi.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'api';

  constructor(private _freeApiService: freeApiService, private http: HttpClient) {

  }


  listComments: any = [];


  ngOnInit() {
    this._freeApiService.getComments().subscribe((data) => {
      this.listComments = data;
      console.log(this.listComments)
    })
  }

  deletes(value: any) {
    this.listComments.splice(value, 1)
  }

  enableEdit = false;
  enableEditIndex = null;

  edit(i: any) {
    this.enableEdit = true;
    this.enableEditIndex = i;
    // console.log(i);
  }

  name: string | undefined;
  result: string | undefined;


  postData() {
    let url = "http://httpbin.org/post";
    this.http.post(url, {
      name:this.name
    }).toPromise().then((data: any) => {
      console.log(data)
      // console.log(JSON.stringify(data.json))
      this.result = JSON.stringify(data.json.name)
    })
  }
}
