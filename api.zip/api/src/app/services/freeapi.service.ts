import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { HttpClient} from '@angular/common/http';

@Injectable() 
export class freeApiService {
    constructor(private httpClient: HttpClient) { }

    getComments() {
        return this.httpClient.get('assets/userData.json')
    }
}